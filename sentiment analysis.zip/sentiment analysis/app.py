from flask import Flask, request, render_template
import pickle
import numpy as np

# Load model and vectorizer
clf = pickle.load(open('clf.pkl', 'rb'))
tfidf = pickle.load(open('tfidf.pkl', 'rb'))

# Optional: preprocessing function (if used in Colab)
def preprocess_text(text):
    return text  # replace with your actual preprocessing logic if needed

# Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def analyze_sentiment():
    sentiment = None
    if request.method == 'POST':
        comment = request.form['comment']
        preprocessed = preprocess_text(comment)
        vector = tfidf.transform([preprocessed])
        prediction = clf.predict(vector)[0]
        sentiment = prediction
    return render_template('index.html', sentiment=sentiment)

if __name__ == '__main__':
    app.run(debug=True)
